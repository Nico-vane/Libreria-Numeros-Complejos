"""
Elaborado por Nicole Vanessa Montaña Gómez
Número de carnet 2163764
A lo largo de este documento vamos a escribir funciones que nos permiten trabajar con números
complejos de la forma (a + bi).
"""

def suma(c_1, c_2):
    """
    La función suma recibe dos números complejos c_1 y c_2 (que deben ser listas de longitud 2)
    y retorna un complejo (lista de longitud 2) correspondiente a la operación c_1 + c_2.
    """
    return [c_1[0] + c_2[0], c_1[1] + c_2[1]]
def resta(c_1, c_2):
    """
    La función resta recibe dos números complejos c_1 y c_2 (que deben ser listas de longitud 2)
    y retorna un complejo (lista de longitud 2) correspondiente a la operación c_1 - c_2.
    """
    return [c_1[0] - c_2[0], c_1[1] - c_2[1]]
def producto(c_1, c_2):
    """
    La función producto recibe dos números complejos c_1 y c_2 (que deben ser listas de longitud 2)
    y retorna un complejo (lista de longitud 2) correspondiente a la operación c_1 * c_2.
    """
    return [(c_1[0] * c_2[0]) - (c_1[1] * c_2[1]), (c_1[0] * c_2[1]) + (c_1[1] * c_2[0])]
def conjugado(c_1):
    """
    La función conjugado recibe un número complejo (lista de longitud 2) y retorna un complejo
    (lista de longitud 2) correspondiente a la operación a - bi.
    """
    return [c_1[0], -(c_1[1])]
def division(c_1, c_2):
    """
    La función division recibe dos números complejos c_1 y c_2 (que deben ser listas de longitud 2)
    y retorna un complejo (lista de longitud 2) correspondiente a la operación c_1 / c_2.
    """
    n_c = conjugado(c_2)
    mul_1 = producto(c_1, n_c)
    mul_2 = producto(c_2, n_c)
    return [mul_1[0]/mul_2[0], mul_1[1]/mul_2[0]]
def forma1(c_1):
    """
    La función forma1 recibe un múmero complejo (de forma [a, b]) y retorna un número complejo de la forma(a + bi).
    """
    return (str (c_1[0]) + "+" + str(c_1[1]) + "i")
def modulo(c_1):
    """
    La función modulo recibe un número complejo (lista de longitud 2) y retorna un número flotante
    correspondiente a la operación (a**2 + b**2)**(1/2).
    """
    return (c_1[0]**2 + c_1[1]**2)**(1/2)
def cartesiana_polar(c_1):
    """
    La función cartesiana_polar recibe un número complejo (lista de longitud dos) que se encuentra en coordenadas
    cartesianas y retorna un complejo (lista de longitud 2) que esta en coordenda polar.
    """
    import math
    ang = math.atan2(c_1[1],c_1[0])
    mod = modulo(c_1)
    return [mod, ang]
def polar_cartesiana(c_1):
    """
    La función polar_cartesiana recibe un número complejo (en la forma de lista de longitud 2) que representa las
    coordenadas polares y retorna un complejo (lista de longitud 2) en forma cartesiana. 
    """
    import math
    ang = math.atan2(c_1[1],c_1[0])
    mod = modulo(c_1)
    return [round(mod * math.cos(ang),2), round(mod * math.sin(ang),2)]
def exponencial(c_1):
    """
    La función exponencial recibe un número complejo (en forma de lista de longitud 2) y retorna un número complejo
    en la forma polar / exponencial (Re^iθ).
    """
    import math
    ang = round(math.atan2(c_1[1],c_1[0]),2)
    mod = round(modulo(c_1),2)
    return (str(mod) + "e" + "^" + "i" + str(ang))
def potencia(c_1,n):
    """
    La función potencia recibe un número complejo (en forma de lista de longitud 2) y un número n el cual indica
    el número al que esta elevado el número complejo, y retorno un número complejo (lista de longitud 2).
    """
    if n == 0:
        mul = 1
    else:
        mul = c_1
        con = 1
        while con < n:
            con = con + 1
            mul = producto(mul,c_1)
    return (mul)
