import calc as c
def test_suma():
    assert c.suma([3, 2], [7, 5]) == [10, 7], "Debe ser 10+7i"

def test_resta():
    assert c.resta([3, 2], [7, 5]) == [-4, -3], "Debe ser -4-3i"

def test_producto():
    assert c.producto([3, 2], [7, 5]) == [11, 29], "Debe ser 11+29i"

def test_conjugado():
    assert c.conjugado([3, 2]) == [3, -2], "Debe ser 3-2i"

def test_division():
    assert c.division([3, 2], [7, 5]) == [0.41, -0.01], "Debe ser 0.41-0-01i"

def test_forma1():
    assert c.forma1([3, 2]) == (3+2i)

def test_modulo():
    assert c.modulo([3, 2]) == (3.60), "Debe ser |[3, 2]| = 3.60"

def test_cartesiana_polar():
    assert c.cartesiana_polar([3, 2]) == [3.60, 0.58], "Debe ser |[3, 2]| = 3.60, θ = 0.58"

def test_polar_cartesiana():
    assert c.polar_cartesiana([3.60, 0.58]) == [3.00, 2.00], "Debe ser 3+2i"

def test_exponencial():
    assert c.exponencial([3, 2]) == ((3.61)e^i(0.58))

def test_potencia():
assert c.potencia([3, 2], 3) == [-9, 46], "Debe ser -9+46i"